-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 21, 2023 at 12:19 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nestecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `banner_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `banner_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `banner_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `banner_status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `banner_title`, `banner_url`, `banner_image`, `banner_status`, `created_at`, `updated_at`) VALUES
(2, 'Everyday Fresh & <br/> Clean with Our <br/> Products', 'https://www.facebook.com/', 'upload/banner/1765667236062415.png', 'active', NULL, '2023-07-19 19:08:59'),
(3, 'Make your Breakfast <br/> Healthy and Easy', 'https://www.youtube.com/', 'upload/banner/1765667213915880.png', 'active', NULL, '2023-06-16 16:10:43'),
(4, 'The best Organic <br/> Products Online', 'https://www.google.com/', 'upload/banner/1765667257048962.png', 'active', NULL, '2023-06-16 16:10:45');

-- --------------------------------------------------------

--
-- Table structure for table `blog_categories`
--

CREATE TABLE `blog_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `blog_category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `blog_category_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `blog_category_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog_categories`
--

INSERT INTO `blog_categories` (`id`, `blog_category_name`, `blog_category_slug`, `blog_category_image`, `status`, `created_at`, `updated_at`) VALUES
(3, 'Financial', 'financial', 'upload/blog/blog_category/1771404301015204.webp', 'active', '2023-07-14 07:33:35', '2023-07-14 07:53:06'),
(4, 'Mobile', 'mobile', 'upload/blog/blog_category/1771420836453202.webp', 'active', '2023-07-14 12:15:55', NULL),
(5, 'Health & Beauty', 'health-&-beauty', 'upload/blog/blog_category/1771420855945698.webp', 'active', '2023-07-14 12:16:13', NULL),
(6, 'Babies & Toys', 'babies-&-toys', 'upload/blog/blog_category/1771420870190199.webp', 'active', '2023-07-14 12:16:27', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `blog_posts`
--

CREATE TABLE `blog_posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `blog_category_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `post_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tags` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `view_counts` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive','pending') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog_posts`
--

INSERT INTO `blog_posts` (`id`, `blog_category_id`, `user_id`, `post_title`, `post_title_slug`, `post_description`, `post_image`, `tags`, `view_counts`, `status`, `created_at`, `updated_at`) VALUES
(2, 3, 1, '4 Expert Tips On How To Choose The Right Men’s Wallet', '4-expert-tips-on-how-to-choose-the-right-men’s-wallet', '<h2 style=\"margin: 0px 0px 10px; padding: 0px; font-weight: 400; font-family: DauphinPlain; font-size: 24px; line-height: 24px; background-color: #ffffff;\">Where can I get some?</h2>\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; text-align: justify; font-family: \'Open Sans\', Arial, sans-serif; font-size: 14px; background-color: #ffffff;\">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; text-align: justify; font-family: \'Open Sans\', Arial, sans-serif; font-size: 14px; background-color: #ffffff;\">&nbsp;</p>\r\n<h2 style=\"margin: 0px 0px 10px; padding: 0px; font-weight: 400; font-family: DauphinPlain; font-size: 24px; line-height: 24px; background-color: #ffffff;\">Where can I get some?</h2>\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; text-align: justify; font-family: \'Open Sans\', Arial, sans-serif; font-size: 14px; background-color: #ffffff;\">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; text-align: justify; font-family: \'Open Sans\', Arial, sans-serif; font-size: 14px; background-color: #ffffff;\">&nbsp;</p>\r\n<h2 style=\"margin: 0px 0px 10px; padding: 0px; font-weight: 400; font-family: DauphinPlain; font-size: 24px; line-height: 24px; background-color: #ffffff;\">Where can I get some?</h2>\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; text-align: justify; font-family: \'Open Sans\', Arial, sans-serif; font-size: 14px; background-color: #ffffff;\">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; text-align: justify; font-family: \'Open Sans\', Arial, sans-serif; font-size: 14px; background-color: #ffffff;\">&nbsp;</p>\r\n<h2 style=\"margin: 0px 0px 10px; padding: 0px; font-weight: 400; font-family: DauphinPlain; font-size: 24px; line-height: 24px; background-color: #ffffff;\">Where can I get some?</h2>\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; text-align: justify; font-family: \'Open Sans\', Arial, sans-serif; font-size: 14px; background-color: #ffffff;\">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>', 'upload/blog/blog_post/1771435598136417.webp', 'foods,money,love', '16', 'active', '2023-07-14 15:31:33', '2023-07-15 10:29:01'),
(3, 5, 1, 'Clutches: How to Buy & Wear a Designer Clutch Bag', 'clutches:-how-to-buy-&-wear-a-designer-clutch-bag', '<h2><span style=\"text-align: justify; background-color: #ffffff;\"><span style=\"font-family: Open Sans, Arial, sans-serif;\"><span style=\"font-size: 14px;\">Clutches: How to Buy &amp; Wear a Designer Clutch Bag</span></span></span></h2>\r\n<p><span style=\"font-family: \'Open Sans\', Arial, sans-serif; font-size: 14px; text-align: justify; background-color: #ffffff;\">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</span></p>\r\n<p><span style=\"font-family: \'Open Sans\', Arial, sans-serif; font-size: 14px; text-align: justify; background-color: #ffffff;\">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</span></p>\r\n<p><span style=\"font-family: \'Open Sans\', Arial, sans-serif; font-size: 14px; text-align: justify; background-color: #ffffff;\">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</span></p>', 'upload/blog/blog_post/1771437610087960.png', 'foods,eat,rice,money', '1', 'active', '2023-07-14 16:42:32', '2023-07-15 10:40:37'),
(4, 5, 1, 'Dynamic Directives Designer', 'dynamic-directives-designer', '<p>Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.Cupiditate tenetur at. Molestias assumenda maxime. Perspiciatis inventore dicta ipsa.Vel quis nesciunt eius reiciendis.</p>', 'upload/blog/blog_post/1771438193436090.png', 'food,rice,rich,hello', '3', 'active', '2023-07-14 16:51:48', '2023-07-15 10:56:57'),
(5, 5, 1, 'Global Metrics Producer', 'global-metrics-producer', '<p>Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.</p>', 'upload/blog/blog_post/1771438237057134.png', 'food,rice,rich,hello', '4', 'active', '2023-07-14 16:52:30', '2023-07-15 10:55:10'),
(6, 4, 1, 'Regional Usability Agent', 'regional-usability-agent', '<p>Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.</p>', 'upload/blog/blog_post/1771438273049461.png', 'food,rice,rich,hello', '4', 'active', '2023-07-14 16:53:04', '2023-07-15 10:40:16'),
(7, 4, 1, 'Regional Usability Agent', 'regional-usability-agent', '<p>Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.</p>', 'upload/blog/blog_post/1771438273049461.png', 'food,rice,rich,hello', '3', 'active', '2023-07-14 16:53:04', '2023-07-15 10:39:53'),
(8, 4, 1, 'Regional Usability Agent', 'regional-usability-agent', '<p>Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.Tempore minima voluptatum officiis beatae deserunt molestias sit earum aspernatur.</p>', 'upload/blog/blog_post/1771438273049461.png', 'food,rice,rich,hello', '4', 'active', '2023-07-14 16:53:04', '2023-07-15 10:27:27');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `brand_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `brand_name`, `brand_slug`, `brand_image`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Walton', 'walton', 'upload/brand/1764820841712151.png', 'active', '2023-05-02 15:51:49', '2023-05-02 15:51:49'),
(2, 'lenovo', 'lenovo', 'upload/brand/1764820849294579.png', 'active', '2023-05-02 15:51:57', '2023-05-02 15:51:57'),
(3, 'Gorilla', 'gorilla', 'upload/brand/1764820858831630.png', 'active', '2023-05-02 15:52:06', '2023-05-02 15:52:06'),
(4, 'iphone', 'iphone', 'upload/brand/1764820867185707.png', 'active', '2023-05-02 15:52:14', '2023-05-02 15:52:14'),
(5, 'asd', 'asd', 'upload/brand/1764820876550439.png', 'active', '2023-05-02 15:52:23', '2023-05-02 15:52:23');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_image_logo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `category_slug`, `category_image`, `category_image_logo`, `status`, `created_at`, `updated_at`) VALUES
(5, 'Women\'s & Girls\' Fashion', 'women\'s-&-girls\'-fashion', 'upload/category/category_image/1765655852065906.jpg', 'upload/category/category_image_logo/1765655852138866.jpg', 'active', NULL, NULL),
(6, 'Health & Beauty', 'health-&-beauty', 'upload/category/category_image/1765655994489326.jpg', 'upload/category/category_image_logo/1765655994587111.jpg', 'active', NULL, NULL),
(7, 'Babies & Toys', 'babies-&-toys', 'upload/category/category_image/1765656093621868.jpg', 'upload/category/category_image_logo/1765656093717285.jpg', 'active', NULL, '2023-05-11 22:13:20'),
(8, 'TV & Home Appliances', 'tv-&-home-appliances', 'upload/category/category_image/1765656210009344.jpg', 'upload/category/category_image_logo/1765656210079928.jpg', 'active', NULL, NULL),
(9, 'Groceries', 'groceries', 'upload/category/category_image/1765656380859150.jpg', 'upload/category/category_image_logo/1765656380959930.jpg', 'active', NULL, NULL),
(10, 'Home & Lifestyle', 'home-&-lifestyle', 'upload/category/category_image/1765657936994020.jpg', 'upload/category/category_image_logo/1765657937080453.jpg', 'active', NULL, NULL),
(11, 'Sports & Outdoors', 'sports-&-outdoors', 'upload/category/category_image/1765658117555249.jpg', 'upload/category/category_image_logo/1765658117649942.jpg', 'active', NULL, NULL),
(12, 'Automotive & Motorbike', 'automotive-&-motorbike', 'upload/category/category_image/1765666188581095.jpg', 'upload/category/category_image_logo/1765666188675702.jpg', 'active', NULL, NULL),
(13, 'Watches, Bags', 'watches,-bags', 'upload/category/category_image/1765666236076770.jpg', 'upload/category/category_image_logo/1765666236169914.jpg', 'active', NULL, NULL),
(14, 'Electronic Accessories', 'electronic-accessories', 'upload/category/category_image/1765666279518771.jpg', 'upload/category/category_image_logo/1765666279613272.jpg', 'active', NULL, NULL),
(15, 'Men\'s & Boys', 'men\'s-&-boys', 'upload/category/category_image/1765666315067855.jpg', 'upload/category/category_image_logo/1765666315124348.jpg', 'active', NULL, NULL),
(16, 'Camping & Hiking', 'camping-&-hiking', 'upload/category/category_image/1765666377684767.jpg', 'upload/category/category_image_logo/1765666377778276.jpg', 'active', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `compare_products`
--

CREATE TABLE `compare_products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `compare_products`
--

INSERT INTO `compare_products` (`id`, `user_id`, `product_id`, `created_at`, `updated_at`) VALUES
(25, 3, 40, '2023-07-18 15:26:55', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `coupon_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coupon_discount` int(11) NOT NULL,
  `coupon_validity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coupon_status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`id`, `coupon_name`, `coupon_discount`, `coupon_validity`, `coupon_status`, `created_at`, `updated_at`) VALUES
(42, 'Bangladesh', 80, '2023-05-26 06:12:21', 'inactive', '2023-05-25 14:12:21', '2023-07-19 19:26:52'),
(43, 'Bangladesh', 80, '2023-05-26 20:12:46', 'inactive', '2023-05-25 14:12:46', '2023-05-25 14:32:28'),
(44, 'Puja', 41, '2023-06-05 20:56:57', 'inactive', '2023-05-25 14:56:57', '2023-07-19 19:26:50'),
(45, 'europe', 15, '2023-05-26 21:00:29', 'inactive', '2023-05-26 05:00:29', '2023-07-19 19:26:49'),
(46, '111', 50, '2023-06-20 14:49:34', 'inactive', '2023-06-15 08:49:34', '2023-07-19 19:26:45');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2023_04_24_210028_create_brands_table', 1),
(6, '2023_04_27_202925_create_categories_table', 1),
(7, '2023_04_28_053658_create_subcategories_table', 1),
(8, '2023_05_02_005959_create_products_table', 2),
(9, '2023_05_02_010035_create_multi_images_table', 2),
(10, '2023_05_10_001632_create_sliders_table', 3),
(11, '2023_05_11_165007_create_banners_table', 4),
(12, '2023_05_24_083425_create_wishlists_table', 5),
(13, '2023_05_24_122008_create_compare_products_table', 6),
(14, '2023_05_25_094445_create_coupons_table', 7),
(15, '2023_05_26_111454_create_shipping_divisions_table', 8),
(16, '2023_05_26_111537_create_shipping_districts_table', 8),
(17, '2023_05_26_111550_create_shipping_states_table', 8),
(18, '2023_06_16_061504_create_orders_table', 9),
(19, '2023_06_16_061516_create_order_items_table', 9),
(20, '2023_07_14_025612_create_blog_categories_table', 10),
(21, '2023_07_14_025649_create_blog_posts_table', 10),
(23, '2023_07_16_172948_create_review_products_table', 11),
(24, '2023_07_17_161034_create_site_settings_table', 12),
(25, '2023_07_17_182350_create_seo_settings_table', 13),
(26, '2023_07_19_112614_create_permission_tables', 14),
(27, '2023_07_20_133406_create_notifications_table', 15);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 67),
(2, 'App\\Models\\User', 68),
(3, 'App\\Models\\User', 1),
(4, 'App\\Models\\User', 70),
(5, 'App\\Models\\User', 69);

-- --------------------------------------------------------

--
-- Table structure for table `multi_images`
--

CREATE TABLE `multi_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` int(11) NOT NULL,
  `photo_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `multi_images`
--

INSERT INTO `multi_images` (`id`, `product_id`, `photo_name`, `created_at`, `updated_at`) VALUES
(161, 39, 'upload/products/multiImage/1766145379073104.webp', '2023-05-17 06:44:47', NULL),
(162, 39, 'upload/products/multiImage/1766145379208005.webp', '2023-05-17 06:44:47', NULL),
(163, 39, 'upload/products/multiImage/1766145379334563.webp', '2023-05-17 06:44:47', NULL),
(164, 39, 'upload/products/multiImage/1766145379462247.webp', '2023-05-17 06:44:47', NULL),
(165, 39, 'upload/products/multiImage/1766145379600739.webp', '2023-05-17 06:44:47', NULL),
(166, 39, 'upload/products/multiImage/1766145379725969.webp', '2023-05-17 06:44:47', NULL),
(167, 40, 'upload/products/multiImage/1766221518393350.webp', '2023-05-18 02:54:59', NULL),
(168, 40, 'upload/products/multiImage/1766221518519584.webp', '2023-05-18 02:54:59', NULL),
(169, 40, 'upload/products/multiImage/1766221518642286.webp', '2023-05-18 02:54:59', NULL),
(170, 40, 'upload/products/multiImage/1766221518764990.webp', '2023-05-18 02:54:59', NULL),
(171, 41, 'upload/products/multiImage/1766221597344511.webp', '2023-05-18 02:56:14', NULL),
(172, 41, 'upload/products/multiImage/1766221597462097.webp', '2023-05-18 02:56:14', NULL),
(173, 41, 'upload/products/multiImage/1766221597580519.webp', '2023-05-18 02:56:14', NULL),
(174, 42, 'upload/products/multiImage/1766221646592349.webp', '2023-05-18 02:57:01', NULL),
(175, 42, 'upload/products/multiImage/1766221646712467.webp', '2023-05-18 02:57:01', NULL),
(176, 42, 'upload/products/multiImage/1766221646852416.webp', '2023-05-18 02:57:01', NULL),
(177, 42, 'upload/products/multiImage/1766221646968389.webp', '2023-05-18 02:57:01', NULL),
(178, 42, 'upload/products/multiImage/1766221647085805.webp', '2023-05-18 02:57:02', NULL),
(179, 44, 'upload/products/multiImage/1766221710897519.webp', '2023-05-18 02:58:02', NULL),
(180, 44, 'upload/products/multiImage/1766221711012999.webp', '2023-05-18 02:58:03', NULL),
(181, 44, 'upload/products/multiImage/1766221711190033.webp', '2023-05-18 02:58:03', NULL),
(182, 44, 'upload/products/multiImage/1766221711315959.webp', '2023-05-18 02:58:03', NULL),
(183, 44, 'upload/products/multiImage/1766221711436620.webp', '2023-05-18 02:58:03', NULL),
(184, 44, 'upload/products/multiImage/1766221711559669.webp', '2023-05-18 02:58:03', NULL),
(185, 44, 'upload/products/multiImage/1766221711682504.webp', '2023-05-18 02:58:03', NULL),
(186, 44, 'upload/products/multiImage/1766221711798070.webp', '2023-05-18 02:58:03', NULL),
(187, 45, 'upload/products/multiImage/1766221770003070.webp', '2023-05-18 02:58:59', NULL),
(188, 45, 'upload/products/multiImage/1766221770121684.webp', '2023-05-18 02:58:59', NULL),
(189, 45, 'upload/products/multiImage/1766221770233388.webp', '2023-05-18 02:58:59', NULL),
(190, 45, 'upload/products/multiImage/1766221770343039.webp', '2023-05-18 02:58:59', NULL),
(191, 45, 'upload/products/multiImage/1766221770460693.webp', '2023-05-18 02:58:59', NULL),
(192, 45, 'upload/products/multiImage/1766221770570800.webp', '2023-05-18 02:58:59', NULL),
(193, 45, 'upload/products/multiImage/1766221770688004.webp', '2023-05-18 02:58:59', NULL),
(194, 46, 'upload/products/multiImage/1766221807001021.webp', '2023-05-18 02:59:34', NULL),
(195, 46, 'upload/products/multiImage/1766221807130588.webp', '2023-05-18 02:59:34', NULL),
(196, 46, 'upload/products/multiImage/1766221807258264.webp', '2023-05-18 02:59:34', NULL),
(197, 46, 'upload/products/multiImage/1766221807371279.webp', '2023-05-18 02:59:34', NULL),
(198, 47, 'upload/products/multiImage/1766221840162192.webp', '2023-05-18 03:00:06', NULL),
(199, 47, 'upload/products/multiImage/1766221840287009.webp', '2023-05-18 03:00:06', NULL),
(200, 47, 'upload/products/multiImage/1766221840415582.webp', '2023-05-18 03:00:06', NULL),
(201, 48, 'upload/products/multiImage/1766221907706836.webp', '2023-05-18 03:01:10', NULL),
(202, 48, 'upload/products/multiImage/1766221907823914.webp', '2023-05-18 03:01:10', NULL),
(203, 48, 'upload/products/multiImage/1766221907953599.webp', '2023-05-18 03:01:10', NULL),
(204, 48, 'upload/products/multiImage/1766221908072248.webp', '2023-05-18 03:01:10', NULL),
(205, 49, 'upload/products/multiImage/1766433681346335.webp', '2023-05-20 11:07:13', NULL),
(206, 49, 'upload/products/multiImage/1766433681476281.webp', '2023-05-20 11:07:13', NULL),
(207, 49, 'upload/products/multiImage/1766433681596578.webp', '2023-05-20 11:07:13', NULL),
(208, 49, 'upload/products/multiImage/1766433681710046.webp', '2023-05-20 11:07:14', NULL),
(209, 49, 'upload/products/multiImage/1766433681869209.webp', '2023-05-20 11:07:14', NULL),
(210, 49, 'upload/products/multiImage/1766433681987949.webp', '2023-05-20 11:07:14', NULL),
(211, 49, 'upload/products/multiImage/1766433682100308.webp', '2023-05-20 11:07:14', NULL),
(212, 49, 'upload/products/multiImage/1766433682217606.webp', '2023-05-20 11:07:14', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) UNSIGNED NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `type`, `notifiable_type`, `notifiable_id`, `data`, `read_at`, `created_at`, `updated_at`) VALUES
('029daa1e-ac66-43ec-a5b5-c018a46925f1', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 19, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:54:14', '2023-07-20 11:54:14'),
('1dd57604-b70b-4293-8290-e1d0ef52fa5b', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 18, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:54:35', '2023-07-20 11:54:35'),
('20408d57-4b8d-4418-810f-e64fa91f8676', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 16, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:54:35', '2023-07-20 11:54:35'),
('20f3be22-8445-416a-990d-7726fd6c712d', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 14, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:54:14', '2023-07-20 11:54:14'),
('2d98c52c-768a-458d-b45f-de22fbd1cda5', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 68, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:41:02', '2023-07-20 11:41:02'),
('2e135283-3d31-4bca-bd2e-dea2881f6cf5', 'App\\Notifications\\OrderComplete', 'App\\Models\\User', 1, '{\"message\":\"New Order Added in Shop\",\"message_type\":\"new_order\"}', NULL, '2023-07-20 11:16:40', '2023-07-20 11:16:40'),
('2fe23176-523e-4cf7-8d62-e09e1cbef3f2', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 66, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:54:35', '2023-07-20 11:54:35'),
('31878988-61bb-4ab0-8272-fdb0b32c4a19', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 73, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:54:35', '2023-07-20 11:54:35'),
('40bea5f3-b569-4a55-9d4c-90f27be3424a', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 70, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:49:13', '2023-07-20 11:49:13'),
('43f68cd7-2938-430c-a15d-5128872a24f5', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 73, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:54:14', '2023-07-20 11:54:14'),
('440057f9-731e-4b70-a273-bdfe06669f56', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 72, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:54:14', '2023-07-20 11:54:14'),
('495f3a5a-d56a-4c45-b647-7c5c5bd2f4ab', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 15, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:54:14', '2023-07-20 11:54:14'),
('59728db8-8011-4279-a2da-bfdd194cd196', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 14, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:54:35', '2023-07-20 11:54:35'),
('5ef4c205-f78d-49ea-9b52-8f449fc80ed4', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 67, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:41:02', '2023-07-20 11:41:02'),
('6d932d61-966d-41c6-a77e-a8ef78fdb53c', 'App\\Notifications\\OrderComplete', 'App\\Models\\User', 67, '{\"message\":\"New Order Added in Shop\",\"message_type\":\"new_order\"}', NULL, '2023-07-20 11:16:40', '2023-07-20 11:16:40'),
('6dc7d8a0-0776-4172-9b52-5b4c709929ca', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 69, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:49:13', '2023-07-20 11:49:13'),
('7874dddf-135f-40e0-9b77-d628657a94a7', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 15, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:54:35', '2023-07-20 11:54:35'),
('7a92994f-3175-482f-9275-ac9b4722d978', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 71, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:54:35', '2023-07-20 11:54:35'),
('7d6e81bd-2238-4981-9b81-8a963ecf6aec', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 2, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:54:14', '2023-07-20 11:54:14'),
('7d837f91-cdb0-427e-92b3-94071780f265', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 66, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:54:14', '2023-07-20 11:54:14'),
('7d8b1b94-d1b3-4863-b9bd-2c9229f61235', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 69, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:41:02', '2023-07-20 11:41:02'),
('8811f95d-906b-46b3-8ee2-bd2371102b0e', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 17, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:54:35', '2023-07-20 11:54:35'),
('8c66ff00-5f2f-4aac-8578-7a02f6fb12d1', 'App\\Notifications\\OrderComplete', 'App\\Models\\User', 69, '{\"message\":\"New Order Added in Shop\",\"message_type\":\"new_order\"}', NULL, '2023-07-20 11:16:40', '2023-07-20 11:16:40'),
('a94c861d-7f5d-453c-b9d9-d6ba81aaa776', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 71, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:54:14', '2023-07-20 11:54:14'),
('b5a949e9-fba8-4da6-ae8c-ba575a999014', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 17, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:54:14', '2023-07-20 11:54:14'),
('b62495b8-8127-47d1-b974-a41730cd37ad', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 67, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:49:13', '2023-07-20 11:49:13'),
('b71c7817-1ae2-40a6-89bc-d0c6e1b15c7f', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 19, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:54:35', '2023-07-20 11:54:35'),
('b783eff3-c463-4054-acc2-d4e77c16f96f', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 1, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:41:02', '2023-07-20 11:41:02'),
('bef13bf2-5225-42d3-b1d2-6193efc7b915', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 70, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:41:02', '2023-07-20 11:41:02'),
('c129e9bb-e8a1-49de-a93e-27cab0e5f94e', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 2, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:54:35', '2023-07-20 11:54:35'),
('c190951a-9632-4a06-84f7-13debfe4b951', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 18, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:54:14', '2023-07-20 11:54:14'),
('d1911438-2a24-4fd5-bf43-6824510c0134', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 1, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:49:13', '2023-07-20 11:49:13'),
('d6905d5e-e68e-42f9-9744-d8a4534a004b', 'App\\Notifications\\OrderComplete', 'App\\Models\\User', 70, '{\"message\":\"New Order Added in Shop\",\"message_type\":\"new_order\"}', NULL, '2023-07-20 11:16:40', '2023-07-20 11:16:40'),
('e90fa10d-4aa3-4f59-8ba9-2ef240c5bbe5', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 72, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:54:35', '2023-07-20 11:54:35'),
('f70a6b6b-9ab4-477c-9f94-f55af589bb9f', 'App\\Notifications\\OrderComplete', 'App\\Models\\User', 68, '{\"message\":\"New Order Added in Shop\",\"message_type\":\"new_order\"}', NULL, '2023-07-20 11:16:40', '2023-07-20 11:16:40'),
('f732d11c-4abd-48b9-afc1-10c38d6cd8d7', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 16, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:54:14', '2023-07-20 11:54:14'),
('fa225dab-18f7-428c-ba2a-b637be50be75', 'App\\Notifications\\vendorApproval', 'App\\Models\\User', 68, '{\"message\":\"Vendor Activated successfully !\",\"message_type\":\"vendor_active\"}', NULL, '2023-07-20 11:49:13', '2023-07-20 11:49:13');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `division_id` bigint(20) UNSIGNED NOT NULL,
  `district_id` bigint(20) UNSIGNED NOT NULL,
  `state_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adress` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `post_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double(8,2) NOT NULL,
  `order_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_month` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_year` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `confirmed_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `processing_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `picked_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipped_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivered_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancel_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancel_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancel_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `return_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `return_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `return_status` int(1) DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `division_id`, `district_id`, `state_id`, `name`, `email`, `phone`, `adress`, `post_code`, `notes`, `payment_type`, `payment_method`, `transaction_id`, `currency`, `amount`, `order_number`, `invoice_no`, `order_date`, `order_month`, `order_year`, `confirmed_date`, `processing_date`, `picked_date`, `shipped_date`, `delivered_date`, `cancel_date`, `cancel_reason`, `cancel_status`, `return_date`, `return_reason`, `return_status`, `status`, `created_at`, `updated_at`) VALUES
(61, 3, 1, 2, 1, 'Masuddsdf', 'user@gmail.com', '01770202036', '1213 walnut street', '19107', 'sdfsdf', 'Cash On Delivery', 'Cash On Delivery', 'cod_XTU1ivjikklnB1kf3KoXvf4G', 'USD', 220.00, NULL, 'EOS217012692', '28 June 2023', 'June', '2023', '03 July 2023', '17 July 2023', NULL, NULL, '17 July 2023', '', '', '', NULL, NULL, NULL, 'delivered', '2023-06-28 13:54:41', '2023-07-17 14:04:56'),
(62, 3, 1, 2, 2, 'Masud', 'user@gmail.com', '01770202036', 'Mirpur 10, Block - D, Road -33, House - 19, Dhaka, Bangladesh', '1216', 'sdsd', 'Cash On Delivery', 'Cash On Delivery', 'cod_xjknNICTBAkaRT3lFZhV7dOo', 'USD', 880.00, NULL, 'EOS524112036', '29 June 2023', 'June', '2023', '01 July 2023', '01 July 2023', NULL, NULL, '01 July 2023', NULL, NULL, NULL, '03 July 2023', 'Wrong product received', 2, 'Canceled', '2023-06-29 07:11:10', '2023-07-03 15:26:46'),
(63, 3, 1, 2, 2, 'Masud', 'user@gmail.com', '01770202036', 'Mirpur 10, Block - D, Road -33, House - 19, Dhaka, Bangladesh', '1216', 'sfsfsfsd', 'Cash On Delivery', 'Cash On Delivery', 'cod_Qa5MWqxL2gpoB9ubfpsZOFmQ', 'USD', 1540.00, NULL, 'EOS686472835', '10 July 2023', ' July', '2023', '10 July 2023', '10 July 2023', NULL, NULL, '10 July 2023', NULL, NULL, NULL, '10 July 2023', 'Wrong product received', 2, 'Canceled', '2023-07-10 08:36:22', '2023-07-10 09:35:32'),
(64, 3, 1, 2, 2, 'Masud', 'user@gmail.com', '01770202036', 'Mirpur 10, Block - D, Road -33, House - 19, Dhaka, Bangladesh', '1216', 'asdad', 'Cash On Delivery', 'Cash On Delivery', 'cod_wffAycFzPVHkZKNh1frGJ0Vk', 'USD', 660.00, NULL, 'EOS168306205', '10 July 2023', 'July', '2023', '17 July 2023', '17 July 2023', NULL, NULL, '17 July 2023', NULL, NULL, NULL, NULL, NULL, NULL, 'delivered', '2023-07-10 09:39:37', '2023-07-17 14:04:47'),
(65, 3, 1, 2, 2, 'Akash', 'user@gmail.com', '01770202036', 'Mirpur 10, Block - D, Road -33, House - 19, Dhaka, Bangladesh', '1212', 'asdasd', 'Cash On Delivery', 'Cash On Delivery', 'cod_9rIONcJPtIILnpRcMDyzLvLr', 'USD', 2640.00, NULL, 'EOS470426203', '10 July 2023', 'July', '2023', '17 July 2023', '17 July 2023', NULL, NULL, '17 July 2023', NULL, NULL, NULL, NULL, NULL, NULL, 'delivered', '2023-07-10 10:14:38', '2023-07-17 14:04:11'),
(66, 3, 1, 2, 2, 'Masud', 'user@gmail.com', '01770202036', 'Mirpur 10, Block - D, Road -33, House - 19, Dhaka, Bangladesh', '1214', 'sdfsdf', 'Cash On Delivery', 'Cash On Delivery', 'cod_wOMhmwZSwi8oRvvG83S1zjFu', 'USD', 1320.00, NULL, 'EOS915373455', '17 July 2023', 'July', '2023', '17 July 2023', '17 July 2023', NULL, NULL, '17 July 2023', NULL, NULL, NULL, NULL, NULL, NULL, 'delivered', '2023-07-17 14:16:22', '2023-07-17 15:34:42'),
(67, 3, 1, 2, 2, 'Masud', 'user@gmail.com', '01770202036', 'Mirpur 10, Block - D, Road -33, House - 19, Dhaka, Bangladesh', '1216', 'asas', 'Cash On Delivery', 'Cash On Delivery', NULL, 'USD', 670.00, NULL, 'EOS117390462', '20 July 2023', ' July ', ' 2023 ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'pending', '2023-07-20 09:36:30', NULL),
(68, 3, 1, 2, 5, 'Masud', 'user@gmail.com', '01770202036', 'Mirpur 10 Dhaka 1216 Bangladesh', '1216', 'asdasd', 'Stripe : card', 'card_1NVz5CGRDbWrVouIgm35ZUgN', 'txn_3NVz5EGRDbWrVouI24hhlsLO', 'usd', 220.00, '64b957331c891', 'EOS599400105', '20 July 2023', 'July', '2023', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'pending', '2023-07-20 09:48:04', NULL),
(69, 3, 1, 2, 2, 'Masud', 'user@gmail.com', '01770202036', 'Mirpur 10, Block - D, Road -33, House - 19, Dhaka, Bangladesh', '1215', 'adasdas', 'Cash On Delivery', 'Cash On Delivery', NULL, 'USD', 220.00, NULL, 'EOS81302072', '20 July 2023', ' July ', ' 2023 ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'pending', '2023-07-20 10:24:42', NULL),
(70, 3, 1, 2, 5, 'Masud', 'user@gmail.com', '01770202036', 'Mirpur 10, Block - D, Road -33, House - 19, Dhaka, Bangladesh', '1221', 'asdasd', 'Cash On Delivery', 'Cash On Delivery', NULL, 'USD', 220.00, NULL, 'EOS261029229', '20 July 2023', ' July ', ' 2023 ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'pending', '2023-07-20 10:31:15', NULL),
(71, 3, 1, 2, 2, 'Masud', 'user@gmail.com', '01770202036', '1213 walnut street', '19107', 'asdasd', 'Cash On Delivery', 'Cash On Delivery', NULL, 'USD', 440.00, NULL, 'EOS66837046', '20 July 2023', ' July ', ' 2023 ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'pending', '2023-07-20 10:33:53', NULL),
(72, 3, 1, 2, 2, 'Masud', 'user@gmail.com', '01770202036', 'Mirpur 10, Block - D, Road -33, House - 19, Dhaka, Bangladesh', '1213', 'aaa', 'Cash On Delivery', 'Cash On Delivery', NULL, 'USD', 440.00, NULL, 'EOS985544093', '20 July 2023', ' July ', ' 2023 ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'pending', '2023-07-20 11:16:34', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `vendor_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qty` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `vendor_id`, `color`, `size`, `qty`, `price`, `created_at`, `updated_at`) VALUES
(52, 61, 47, NULL, NULL, NULL, '1', 220.00, '2023-06-28 13:54:46', NULL),
(53, 62, 49, '17', 'Yellow', 'Medium', '4', 220.00, '2023-06-29 07:11:16', NULL),
(54, 63, 47, '2', 'Red', 'Small', '1', 220.00, '2023-07-10 08:36:28', NULL),
(55, 63, 40, '2', 'Red', 'Small', '2', 220.00, '2023-07-10 08:36:28', NULL),
(56, 63, 42, '2', 'Red', 'Small', '2', 220.00, '2023-07-10 08:36:28', NULL),
(57, 63, 44, '2', 'Red', 'Small', '2', 220.00, '2023-07-10 08:36:28', NULL),
(58, 64, 47, NULL, NULL, NULL, '1', 220.00, '2023-07-10 09:39:43', NULL),
(59, 64, 40, NULL, NULL, NULL, '1', 220.00, '2023-07-10 09:39:43', NULL),
(60, 64, 41, NULL, NULL, NULL, '1', 220.00, '2023-07-10 09:39:43', NULL),
(61, 65, 47, '2', 'Red', 'Small', '1', 220.00, '2023-07-10 10:14:45', NULL),
(62, 65, 40, '2', 'Red', 'Small', '1', 220.00, '2023-07-10 10:14:45', NULL),
(63, 65, 41, '2', 'Red', 'Small', '10', 220.00, '2023-07-10 10:14:45', NULL),
(64, 66, 40, '2', 'Red', 'Small', '6', 220.00, '2023-07-17 14:16:27', NULL),
(65, 67, 39, NULL, NULL, NULL, '1', 450.00, '2023-07-20 09:36:36', NULL),
(66, 67, 40, '2', 'Red', 'Small', '1', 220.00, '2023-07-20 09:36:36', NULL),
(67, 68, 41, '2', 'Red', 'Small', '1', 220.00, '2023-07-20 09:48:09', NULL),
(68, 69, 40, '2', 'Red', 'Small', '1', 220.00, '2023-07-20 10:24:48', NULL),
(69, 70, 40, '2', 'Red', 'Small', '1', 220.00, '2023-07-20 10:31:24', NULL),
(70, 71, 47, '14', 'Red', 'Small', '1', 220.00, '2023-07-20 10:33:59', NULL),
(71, 71, 41, '14', 'Red', 'Small', '1', 220.00, '2023-07-20 10:33:59', NULL),
(72, 72, 47, '2', 'Red', 'Small', '1', 220.00, '2023-07-20 11:16:40', NULL),
(73, 72, 41, '2', 'Red', 'Small', '1', 220.00, '2023-07-20 11:16:40', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `group_name`, `created_at`, `updated_at`) VALUES
(2, 'brand.list', 'web', 'brand', '2023-07-19 16:19:56', '2023-07-19 16:19:56'),
(3, 'brand.add', 'web', 'brand', '2023-07-19 16:21:08', '2023-07-19 16:21:08'),
(4, 'brand.edit', 'web', 'brand', '2023-07-19 16:21:25', '2023-07-19 16:21:25'),
(5, 'brand.delete', 'web', 'brand', '2023-07-19 16:21:34', '2023-07-19 16:21:34'),
(6, 'cat.menu', 'web', 'category', '2023-07-19 16:21:50', '2023-07-19 16:21:50'),
(7, 'category.list', 'web', 'category', '2023-07-19 16:21:57', '2023-07-19 16:21:57'),
(8, 'category.add', 'web', 'category', '2023-07-19 16:22:04', '2023-07-19 16:22:04'),
(9, 'category.edit', 'web', 'category', '2023-07-19 16:22:11', '2023-07-19 16:22:11'),
(10, 'category.delete', 'web', 'category', '2023-07-19 16:22:23', '2023-07-19 16:22:23'),
(11, 'subcategory.menu', 'web', 'subcategory', '2023-07-19 16:22:36', '2023-07-19 16:22:36'),
(12, 'subcategory.list', 'web', 'subcategory', '2023-07-19 16:22:42', '2023-07-19 16:22:42'),
(13, 'subcategory.add', 'web', 'subcategory', '2023-07-19 16:22:48', '2023-07-19 16:22:48'),
(14, 'subcategory.edit', 'web', 'subcategory', '2023-07-19 16:22:55', '2023-07-19 16:22:55'),
(15, 'subcategory.delete', 'web', 'subcategory', '2023-07-19 16:23:03', '2023-07-19 16:23:03'),
(16, 'product.menu', 'web', 'product', '2023-07-19 16:23:12', '2023-07-19 16:23:12'),
(17, 'product.list', 'web', 'product', '2023-07-19 16:23:18', '2023-07-19 16:23:18'),
(18, 'product.add', 'web', 'product', '2023-07-19 16:23:26', '2023-07-19 16:23:26'),
(19, 'product.edit', 'web', 'product', '2023-07-19 16:23:32', '2023-07-19 16:23:32'),
(20, 'product.delete', 'web', 'product', '2023-07-19 16:23:40', '2023-07-19 16:23:40'),
(21, 'slider.menu', 'web', 'slider', '2023-07-19 16:23:49', '2023-07-19 16:23:49'),
(22, 'slider.list', 'web', 'slider', '2023-07-19 16:23:55', '2023-07-19 16:23:55'),
(23, 'slider.add', 'web', 'slider', '2023-07-19 16:24:04', '2023-07-19 16:24:04'),
(24, 'slider.edit', 'web', 'slider', '2023-07-19 16:24:10', '2023-07-19 16:24:10'),
(25, 'slider.delete', 'web', 'slider', '2023-07-19 16:24:17', '2023-07-19 16:24:17'),
(26, 'ads.menu', 'web', 'ads', '2023-07-19 16:24:27', '2023-07-19 16:24:27'),
(27, 'ads.list', 'web', 'ads', '2023-07-19 16:24:35', '2023-07-19 16:24:35'),
(28, 'ads.add', 'web', 'ads', '2023-07-19 16:24:43', '2023-07-19 16:24:43'),
(29, 'ads.edit', 'web', 'ads', '2023-07-19 16:27:53', '2023-07-19 16:27:53'),
(30, 'ads.delete', 'web', 'ads', '2023-07-19 16:28:06', '2023-07-19 16:28:06'),
(31, 'coupon.menu', 'web', 'coupon', '2023-07-19 16:28:14', '2023-07-19 16:28:14'),
(32, 'coupon.list', 'web', 'coupon', '2023-07-19 16:28:21', '2023-07-19 16:28:21'),
(33, 'coupon.add', 'web', 'coupon', '2023-07-19 16:28:29', '2023-07-19 16:28:29'),
(34, 'coupon.edit', 'web', 'coupon', '2023-07-19 16:28:37', '2023-07-19 16:28:37'),
(35, 'coupon.delete', 'web', 'coupon', '2023-07-19 16:28:49', '2023-07-19 16:28:49'),
(36, 'area.menu', 'web', 'area', '2023-07-19 16:29:01', '2023-07-19 16:29:01'),
(37, 'vendor.menu', 'web', 'vendor', '2023-07-19 16:29:10', '2023-07-19 16:29:10'),
(38, 'order.menu', 'web', 'order', '2023-07-19 16:29:17', '2023-07-19 16:29:17'),
(39, 'order.list', 'web', 'order', '2023-07-19 16:29:24', '2023-07-19 16:29:24'),
(40, 'order.edit', 'web', 'order', '2023-07-19 16:29:31', '2023-07-19 16:29:31'),
(41, 'order.delete', 'web', 'order', '2023-07-19 16:29:37', '2023-07-19 16:29:37'),
(42, 'return.order.menu', 'web', 'return', '2023-07-19 16:29:54', '2023-07-19 16:29:54'),
(43, 'user.management.menu', 'web', 'user', '2023-07-19 16:30:03', '2023-07-19 16:30:03'),
(44, 'review.menu', 'web', 'review', '2023-07-19 16:30:11', '2023-07-19 16:30:11'),
(45, 'blog.menu', 'web', 'blog', '2023-07-19 16:30:18', '2023-07-19 16:30:18'),
(46, 'site.menu', 'web', 'setting', '2023-07-19 16:30:29', '2023-07-19 16:30:29'),
(47, 'role.permission.menu', 'web', 'role', '2023-07-19 16:30:40', '2023-07-19 16:30:40'),
(48, 'admin.user.menu', 'web', 'admin', '2023-07-19 16:31:01', '2023-07-19 16:31:01'),
(49, 'brand.menu', 'web', 'brand', '2023-07-19 16:38:17', '2023-07-19 16:38:17'),
(50, 'banner.menu', 'web', 'banner', '2023-07-19 19:09:31', '2023-07-19 19:09:31'),
(51, 'banner.list', 'web', 'banner', '2023-07-19 19:09:48', '2023-07-19 19:09:48'),
(52, 'banner.edit', 'web', 'banner', '2023-07-19 19:09:58', '2023-07-19 19:09:58'),
(53, 'banner.delete', 'web', 'banner', '2023-07-19 19:10:08', '2023-07-19 19:10:08'),
(54, 'report.menu', 'web', 'report', '2023-07-19 19:21:23', '2023-07-19 19:21:23');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `brand_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_qty` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_size` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_tags` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selling_price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount_price` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_descp` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `long_descp` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendor_id` int(11) DEFAULT NULL,
  `hot_deals` int(11) DEFAULT NULL,
  `featured` int(11) DEFAULT NULL,
  `special_offer` int(11) DEFAULT NULL,
  `special_deals` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `brand_id`, `category_id`, `subcategory_id`, `product_name`, `product_slug`, `product_code`, `product_qty`, `product_size`, `product_tags`, `product_color`, `selling_price`, `discount_price`, `short_descp`, `long_descp`, `product_thumbnail`, `vendor_id`, `hot_deals`, `featured`, `special_offer`, `special_deals`, `status`, `created_at`, `updated_at`) VALUES
(39, 5, 15, 56, 'Richman Mens Slim Fit Casual Blue Cotton Short Sleeve T Shirt', 'richman-mens-slim-fit-casual-blue-cotton-short-sleeve-t-shirt', 'asd001', '0', 'Small,Medium,Large', 'fashion,health,beauty', 'Red,Green,Blue,Yellow', '450', NULL, 'dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', '<h1>product is good</h1>\r\n<p>dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>\r\n<p>&lt;hr&gt;</p>\r\n<h3>product is good</h3>\r\n<p>&lt;hr&gt;</p>\r\n<p>e and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageM</p>\r\n<p>&nbsp;</p>', 'upload/products/thumbnail/1766145378813734.webp', 14, NULL, 1, 1, NULL, 1, '2023-05-17 06:44:47', '2023-05-18 02:55:40'),
(40, 5, 15, 56, 'Richman Mens Slim Fit Casual Blue Cotton Short Sleeve T Shirt', 'richman-mens-slim-fit-casual-blue-cotton-short-sleeve-t-shirt', 'asd55', '464', 'Small,Medium,Large', 'fashion,health,beauty', 'Red,Green,Blue,Yellow', '450', '220', 'dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', '<h1>product is good</h1>\r\n<p>dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>\r\n<p>&lt;hr&gt;</p>\r\n<h3>product is good</h3>\r\n<p>&lt;hr&gt;</p>\r\n<p>e and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageM</p>\r\n<p>&nbsp;</p>', 'upload/products/thumbnail/1766221518248700.webp', 2, NULL, 1, 1, NULL, 1, '2023-05-18 02:54:59', '2023-07-17 15:34:42'),
(41, 5, 15, 56, 'Richman Mens Slim Fit Casual Blue Cotton Short Sleeve T Shirt', 'richman-mens-slim-fit-casual-blue-cotton-short-sleeve-t-shirt', 'asd55', '470', 'Small,Medium,Large', 'fashion,health,beauty', 'Red,Green,Blue,Yellow', '450', '220', 'dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', '<h1>product is good</h1>\r\n<p>dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>\r\n<p>&lt;hr&gt;</p>\r\n<h3>product is good</h3>\r\n<p>&lt;hr&gt;</p>\r\n<p>e and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageM</p>\r\n<p>&nbsp;</p>', 'upload/products/thumbnail/1766221597219773.webp', 2, 1, 1, 1, NULL, 1, '2023-05-18 02:56:14', NULL),
(42, 5, 15, 56, 'Richman Mens Slim Fit Casual Blue Cotton Short Sleeve T Shirt', 'richman-mens-slim-fit-casual-blue-cotton-short-sleeve-t-shirt', 'asd55', '470', 'Small,Medium,Large', 'fashion,health,beauty', 'Red,Green,Blue,Yellow', '450', '220', 'dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', '<h1>product is good</h1>\r\n<p>dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>\r\n<p>&lt;hr&gt;</p>\r\n<h3>product is good</h3>\r\n<p>&lt;hr&gt;</p>\r\n<p>e and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageM</p>\r\n<p>&nbsp;</p>', 'upload/products/thumbnail/1766221646471001.webp', 2, NULL, 1, 1, NULL, 1, '2023-05-18 02:57:01', NULL),
(43, 5, 15, 56, 'Pants Slim Fit Casual Blue Cotton Short Sleeve T Shirt', 'pants-slim-fit-casual-blue-cotton-short-sleeve-t-shirt', 'asd55', '470', 'Small,Medium,Large', 'fashion,health,beauty', 'Red,Green,Blue,Yellow', '450', '220', 'dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', '<h1>product is good</h1>\r\n<p>dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>\r\n<p>&lt;hr&gt;</p>\r\n<h3>product is good</h3>\r\n<p>&lt;hr&gt;</p>\r\n<p>e and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageM</p>\r\n<p>&nbsp;</p>', 'upload/products/thumbnail/1766221687311411.webp', 2, 1, 1, 1, NULL, 1, '2023-05-18 02:57:40', NULL),
(44, 5, 15, 56, 'Richman Mens Slim Fit Casual Blue Cotton Short Sleeve T Shirt', 'richman-mens-slim-fit-casual-blue-cotton-short-sleeve-t-shirt', 'asd55', '470', 'Small,Medium,Large', 'fashion,health,beauty', 'Red,Green,Blue,Yellow', '450', '220', 'dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', '<h1>product is good</h1>\r\n<p>dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>\r\n<p>&lt;hr&gt;</p>\r\n<h3>product is good</h3>\r\n<p>&lt;hr&gt;</p>\r\n<p>e and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageM</p>\r\n<p>&nbsp;</p>', 'upload/products/thumbnail/1766221710773454.webp', 2, 1, 1, 1, NULL, 1, '2023-05-18 02:58:02', NULL),
(45, 4, 8, 29, 'Mobile', 'mobile', 'asd55', '470', 'Small,Medium,Large', 'fashion,health,beauty', 'Red,Green,Blue,Yellow', '450', '220', 'dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', '<h1>product is good</h1>\r\n<p>dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>\r\n<p>&lt;hr&gt;</p>\r\n<h3>product is good</h3>\r\n<p>&lt;hr&gt;</p>\r\n<p>e and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageM</p>\r\n<p>&nbsp;</p>', 'upload/products/thumbnail/1766221769875878.webp', 14, NULL, 1, 1, NULL, 1, '2023-05-18 02:58:59', NULL),
(46, 4, 8, 36, 'Keyboards', 'keyboards', 'asd55', '470', 'Small,Medium,Large', 'fashion,health,beauty', 'Red,Green,Blue,Yellow', '450', '220', 'dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', '<h1>product is good</h1>\r\n<p>dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>\r\n<p>&lt;hr&gt;</p>\r\n<h3>product is good</h3>\r\n<p>&lt;hr&gt;</p>\r\n<p>e and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageM</p>\r\n<p>&nbsp;</p>', 'upload/products/thumbnail/1766221806865865.webp', 14, NULL, 1, 1, NULL, 1, '2023-05-18 02:59:34', NULL),
(47, 4, 8, 31, 'Samsung', 'samsung', 'asd55', '470', 'Small,Medium,Large', 'fashion,health,beauty', 'Red,Green,Blue,Yellow', '450', '220', 'dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', '<h1>product is good</h1>\r\n<p>dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>\r\n<p>&lt;hr&gt;</p>\r\n<h3>product is good</h3>\r\n<p>&lt;hr&gt;</p>\r\n<p>e and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageM</p>\r\n<p>&nbsp;</p>', 'upload/products/thumbnail/1766221839979704.webp', 2, 1, 1, 1, NULL, 1, '2023-05-18 03:00:06', NULL),
(48, 4, 8, 36, 'Lava', 'lava', 'asd55', '470', 'Small,Medium,Large', 'fashion,health,beauty', 'Red,Green,Blue,Yellow', '450', NULL, 'dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', '<h1>product is good</h1>\r\n<p>dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>\r\n<p>&lt;hr&gt;</p>\r\n<h3>product is good</h3>\r\n<p>&lt;hr&gt;</p>\r\n<p>e and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageM</p>\r\n<p>&nbsp;</p>', 'upload/products/thumbnail/1766221907582504.webp', 2, NULL, 1, 1, NULL, 1, '2023-05-18 03:01:10', '2023-07-10 10:44:06'),
(49, 3, 8, 36, 'Richman Mens Slim Fit Casual Blue Cotton Short Sleeve T Shirt', 'richman-mens-slim-fit-casual-blue-cotton-short-sleeve-t-shirt', 'asd55', '470', 'Small,Medium,Large', 'fashion,health,beauty', 'Red,Green,Blue,Yellow', '450', '220', 'dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum', '<h1>product is good</h1>\r\n<p>dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>\r\n<p>&lt;hr&gt;</p>\r\n<h3>product is good</h3>\r\n<p>&lt;hr&gt;</p>\r\n<p>e and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageM</p>\r\n<p>&nbsp;</p>', 'upload/products/thumbnail/1766433681154669.webp', 17, 1, 1, 1, 1, 1, '2023-05-20 11:07:13', '2023-06-16 16:09:43');

-- --------------------------------------------------------

--
-- Table structure for table `review_products`
--

CREATE TABLE `review_products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `vendor_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `review_products`
--

INSERT INTO `review_products` (`id`, `product_id`, `user_id`, `comment`, `rating`, `status`, `vendor_id`, `created_at`, `updated_at`) VALUES
(1, 39, 3, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus, suscipit exercitationem accusantium obcaecati quos voluptate nesciunt facilis itaque modi commodi dignissimos sequi repudiandae minus ab deleniti totam officia id inciduntLorem ipsum dolo', '5', '1', 14, '2023-06-01 17:12:29', '2023-07-16 21:01:44'),
(2, 39, 3, 'helee', '1', '1', 14, '2023-06-01 17:12:29', '2023-07-16 20:50:54'),
(3, 40, 3, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus, suscipit exercitationem accusantium obcaecati quos voluptate nesciunt facilis itaque modi commodi dignissimos sequi repudiandae minus ab deleniti totam officia id incidunt?', '5', '1', 2, NULL, '2023-07-16 20:55:11'),
(4, 40, 3, 'quos voluptate nesciunt facilis itaque modi commodi dignissimos sequi repudiandae minus ab deleniti totam officia id incidun', '1', '1', 2, NULL, '2023-07-16 20:57:50'),
(5, 40, 3, 'quos voluptate nesciunt facilis itaque modi commodi dignissimos sequi repudiandae minus ab deleniti totam officia id incidun', '4', '1', 2, NULL, '2023-07-16 20:56:30'),
(6, 40, 3, 'quos voluptate nesciunt facilis itaque modi commodi dignissimos sequi repudiandae minus ab deleniti totam officia id incidun', '5', '1', 2, NULL, '2023-07-16 21:00:00'),
(7, 39, 3, 'quos voluptate nesciunt facilis itaque modi commodi dignissimos sequi repudiandae minus ab deleniti totam officia id incidquos voluptate nesciunt facilis itaque modi commodi dignissimos sequi repudiandae minus ab deleniti totam officia id incidquos volup', '4', '0', 14, NULL, NULL),
(8, 39, 3, 'quos voluptate nesciunt facilis itaque modi commodi dignissimos sequi repudiandae minus ab deleniti totam officia id incidquos voluptate nesciunt facilis itaque modi commodi dignissimos sequi repudiandae minus ab deleniti totam officia id incidquos volupt', '5', '0', 14, NULL, NULL),
(9, 39, 3, 'quos voluptate nesciunt facilis itaque modi commodi dignissimos sequi repudiandae minus ab deleniti totam officia id incidquos voluptate nesciunt facilis itaque modi commodi dignissimos sequi repudiandae minus ab deleniti totam officia id incidquos volupj', '1', '0', 14, NULL, '2023-07-16 21:16:22');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'Super Admin', 'web', '2023-07-19 16:45:24', '2023-07-19 16:45:24'),
(2, 'CEO', 'web', '2023-07-19 16:45:34', '2023-07-19 16:45:34'),
(3, 'Admin', 'web', '2023-07-19 16:45:41', '2023-07-19 16:45:41'),
(4, 'Accountent', 'web', '2023-07-19 16:47:49', '2023-07-19 16:47:49'),
(5, 'Marketing', 'web', '2023-07-19 16:48:02', '2023-07-19 16:48:02');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(2, 1),
(2, 2),
(3, 1),
(3, 2),
(4, 1),
(4, 2),
(5, 1),
(5, 2),
(6, 1),
(6, 2),
(7, 1),
(7, 2),
(8, 1),
(8, 2),
(9, 1),
(9, 2),
(10, 1),
(10, 2),
(11, 1),
(11, 2),
(12, 1),
(12, 2),
(13, 1),
(13, 2),
(14, 1),
(14, 2),
(15, 1),
(15, 2),
(16, 1),
(16, 2),
(16, 4),
(16, 5),
(17, 1),
(17, 2),
(17, 4),
(17, 5),
(18, 1),
(18, 2),
(19, 1),
(19, 2),
(20, 1),
(20, 2),
(21, 1),
(21, 2),
(22, 1),
(22, 2),
(23, 1),
(23, 2),
(24, 1),
(24, 2),
(25, 1),
(25, 2),
(26, 1),
(26, 2),
(26, 3),
(27, 1),
(27, 2),
(28, 1),
(28, 2),
(29, 1),
(29, 2),
(30, 1),
(30, 2),
(31, 1),
(31, 2),
(31, 4),
(31, 5),
(32, 1),
(32, 2),
(32, 4),
(32, 5),
(33, 1),
(33, 2),
(33, 4),
(34, 1),
(34, 2),
(34, 4),
(35, 1),
(35, 2),
(35, 4),
(36, 1),
(36, 2),
(36, 5),
(37, 1),
(37, 2),
(37, 4),
(38, 1),
(38, 2),
(38, 4),
(38, 5),
(39, 1),
(39, 2),
(39, 4),
(40, 1),
(40, 2),
(41, 1),
(41, 2),
(42, 1),
(42, 2),
(42, 4),
(43, 1),
(43, 2),
(44, 1),
(44, 2),
(45, 1),
(45, 2),
(45, 5),
(46, 1),
(46, 2),
(47, 1),
(48, 1),
(48, 2),
(49, 1),
(49, 2);

-- --------------------------------------------------------

--
-- Table structure for table `seo_settings`
--

CREATE TABLE `seo_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_author` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_keyword` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `seo_settings`
--

INSERT INTO `seo_settings` (`id`, `meta_title`, `meta_author`, `meta_keyword`, `meta_description`, `created_at`, `updated_at`) VALUES
(1, 'Nest Ecommerce | Multipurpose website', 'Md Ibrahim Khalil', 'Owner,Controller,Developer', 'This is a multipurpose ecommerce website', '2023-07-17 18:29:57', '2023-07-17 12:42:50');

-- --------------------------------------------------------

--
-- Table structure for table `shipping_districts`
--

CREATE TABLE `shipping_districts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `division_id` bigint(20) UNSIGNED NOT NULL,
  `district_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shipping_districts`
--

INSERT INTO `shipping_districts` (`id`, `division_id`, `district_name`, `status`, `created_at`, `updated_at`) VALUES
(2, 1, 'Mirpur', 'active', '2023-05-31 09:19:20', NULL),
(3, 1, 'Banani', 'active', '2023-05-31 09:19:33', NULL),
(5, 8, 'Dinajpur', 'active', '2023-05-31 09:41:11', NULL),
(6, 8, 'Kurigram', 'active', '2023-05-31 09:41:19', NULL),
(7, 8, 'Gaibandha', 'active', '2023-05-31 09:41:27', NULL),
(8, 8, 'Lalmonirhat', 'active', '2023-05-31 09:41:34', NULL),
(9, 8, 'Nilphamari', 'active', '2023-05-31 09:41:40', NULL),
(10, 8, 'Panchagarh', 'active', '2023-05-31 09:41:46', NULL),
(11, 8, 'Rangpur', 'active', '2023-05-31 09:41:53', NULL),
(12, 8, 'Thakurgaon', 'active', '2023-05-31 09:42:02', '2023-07-14 15:25:13');

-- --------------------------------------------------------

--
-- Table structure for table `shipping_divisions`
--

CREATE TABLE `shipping_divisions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `division_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shipping_divisions`
--

INSERT INTO `shipping_divisions` (`id`, `division_name`, `status`, `created_at`, `updated_at`) VALUES
(1, 'DHAKA', 'active', NULL, '2023-06-16 16:11:25'),
(3, 'CHITTAGONG', 'active', '2023-05-26 07:05:35', NULL),
(4, 'RAJSHAHI', 'active', '2023-05-26 07:05:43', NULL),
(5, 'SYLHET', 'active', '2023-05-26 07:05:52', NULL),
(6, 'KHULNA', 'active', '2023-05-26 07:06:01', NULL),
(7, 'BARISAL', 'active', '2023-05-26 07:06:10', '2023-05-31 06:30:15'),
(8, 'RANGPUR', 'active', '2023-05-26 07:06:18', '2023-07-14 15:25:07');

-- --------------------------------------------------------

--
-- Table structure for table `shipping_states`
--

CREATE TABLE `shipping_states` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `division_id` bigint(20) UNSIGNED NOT NULL,
  `district_id` bigint(20) UNSIGNED NOT NULL,
  `state_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shipping_states`
--

INSERT INTO `shipping_states` (`id`, `division_id`, `district_id`, `state_name`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 'Lalmatia', 'active', '2023-05-31 10:09:52', NULL),
(2, 1, 2, 'bangladesh', 'active', '2023-05-31 10:31:32', NULL),
(3, 8, 10, 'bangladesh', 'active', '2023-05-31 10:32:00', NULL),
(5, 1, 2, 'Kalshi', 'active', '2023-05-31 10:50:45', '2023-05-31 11:14:57');

-- --------------------------------------------------------

--
-- Table structure for table `site_settings`
--

CREATE TABLE `site_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_desc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `open_hours` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active_days` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `support_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_one` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pinterest` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `copyright` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `site_settings`
--

INSERT INTO `site_settings` (`id`, `logo`, `short_desc`, `message`, `open_hours`, `active_days`, `support_phone`, `phone_one`, `email`, `company_address`, `facebook`, `twitter`, `youtube`, `instagram`, `pinterest`, `copyright`, `created_at`, `updated_at`) VALUES
(1, 'upload/logo/1771695352055121.webp', 'Awesome grocery store website template', 'Up to 15% discount on your first subscribe', '09:00 AM to 09:00 PM', 'Saturday to Friday', '1900 - 888', '(+91) - 540-025-124553', 'sale@Nest.com', '5171 W Campbell Ave undefined Kent, Utah 53127 United States', 'https://www.facebook.com/', 'https://www.twitter.com/', 'https://www.youtube.com/', 'https://www.instagram.com/', 'https://www.pinterest.com/', 'Copyright © 2023. All right reserved.', '2023-07-17 11:58:32', '2023-07-17 12:59:14');

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slider_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slider_short` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slider_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slider_status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `slider_title`, `slider_short`, `slider_image`, `slider_status`, `created_at`, `updated_at`) VALUES
(3, 'Fresh Vegetables <br> Big discount', 'Save up to 50% off on your first order', 'upload/slider/1765664851600629.png', 'active', NULL, '2023-07-14 15:24:46'),
(4, 'Don’t miss amazing <br> grocery deals', 'Sign up for the daily newsletter', 'upload/slider/1765664888522275.png', 'active', NULL, '2023-06-16 16:10:18');

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

CREATE TABLE `subcategories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `subcategory_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subcategory_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subcategory_status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subcategories`
--

INSERT INTO `subcategories` (`id`, `category_id`, `subcategory_name`, `subcategory_slug`, `subcategory_status`, `created_at`, `updated_at`) VALUES
(14, 5, 'Traditional Clothing', 'traditional-clothing', 'active', NULL, '2023-06-19 11:34:12'),
(15, 5, 'Abaya Borka', 'abaya-borka', 'active', NULL, NULL),
(16, 5, 'Clothing', 'clothing', 'active', NULL, NULL),
(17, 5, 'Lingerie, Sleep & Lounge', 'lingerie,-sleep-&-lounge', 'active', NULL, NULL),
(18, 5, 'Shoes', 'shoes', 'active', NULL, NULL),
(19, 6, 'Skin Care', 'skin-care', 'active', NULL, NULL),
(20, 6, 'Hair Care', 'hair-care', 'active', NULL, NULL),
(21, 6, 'Makeup', 'makeup', 'active', NULL, NULL),
(22, 6, 'Fragrances', 'fragrances', 'active', NULL, NULL),
(23, 6, 'Beauty Tools', 'beauty-tools', 'active', NULL, NULL),
(24, 7, 'Diapering & Potty', 'diapering-&-potty', 'active', NULL, NULL),
(25, 7, 'Feeding', 'feeding', 'active', NULL, NULL),
(26, 7, 'Baby Personal Care', 'baby-personal-care', 'active', NULL, NULL),
(27, 7, 'Baby Gear', 'baby-gear', 'active', NULL, NULL),
(28, 7, 'Nursery', 'nursery', 'active', NULL, NULL),
(29, 8, 'Televisions', 'televisions', 'active', NULL, NULL),
(30, 8, 'Audio', 'audio', 'active', NULL, NULL),
(31, 8, 'TV Accessories', 'tv-accessories', 'active', NULL, NULL),
(32, 8, 'Cooling & Heating', 'cooling-&-heating', 'active', NULL, NULL),
(33, 8, 'Kitchen Appliances', 'kitchen-appliances', 'active', NULL, NULL),
(34, 8, 'Refrigerators', 'refrigerators', 'active', NULL, NULL),
(35, 8, 'Microwaves', 'microwaves', 'active', NULL, NULL),
(36, 8, 'Air Conditioners', 'air-conditioners', 'active', NULL, NULL),
(37, 9, 'Fresh Produce', 'fresh-produce', 'active', NULL, NULL),
(38, 9, 'Breakfast', 'breakfast', 'active', NULL, NULL),
(39, 9, 'Cooking Ingredients', 'cooking-ingredients', 'active', NULL, NULL),
(40, 9, 'Snacks', 'snacks', 'active', NULL, NULL),
(41, 9, 'UHT, Milk & Milk Powder', 'uht,-milk-&-milk-powder', 'active', NULL, NULL),
(42, 10, 'Bath', 'bath', 'active', NULL, NULL),
(43, 10, 'Bedding', 'bedding', 'active', NULL, NULL),
(44, 10, 'Cleaning', 'cleaning', 'active', NULL, NULL),
(45, 10, 'Laundry', 'laundry', 'active', NULL, NULL),
(46, 10, 'Bakeware', 'bakeware', 'active', NULL, NULL),
(47, 10, 'Coffee & Tea', 'coffee-&-tea', 'active', NULL, NULL),
(48, 10, 'Cookware', 'cookware', 'active', NULL, NULL),
(49, 11, 'Cookware', 'cookware', 'active', NULL, NULL),
(50, 11, 'Exercise & Fitness', 'exercise-&-fitness', 'active', NULL, NULL),
(51, 11, 'Treadmills', 'treadmills', 'active', NULL, NULL),
(52, 11, 'Exercise Bikes', 'exercise-bikes', 'active', NULL, NULL),
(53, 11, 'Dumbbells', 'dumbbells', 'active', NULL, NULL),
(54, 11, 'Cycling', 'cycling', 'active', NULL, NULL),
(55, 11, 'Boxing, Martial Arts & MMA', 'boxing,-martial-arts-&-mma', 'active', NULL, NULL),
(56, 15, 'Mens', 'mens', 'active', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sid` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `join_date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '2022',
  `short_desc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('admin','vendor','user') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `is_active` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `sid`, `name`, `username`, `email`, `email_verified_at`, `password`, `photo`, `phone`, `address`, `join_date`, `short_desc`, `role`, `status`, `is_active`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Admin', 'lara', 'zanin@gmail.com', NULL, '$2y$10$hReTvexhVeNXAL..8wvfIe.2kzYQK6cFdibUjuS3Vkt1kBsgk2aC2', '2023041543png', '01705543225', 'Germany', '2022', 'dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic t', 'admin', 'active', '2023-07-20 01:26:26', 'gGFqd2uJDZPhq06dpD8u1UxIlANst8JremXsr5EWSpXWhggz20eTrtsPZ7bs', NULL, '2023-07-19 19:26:26'),
(2, NULL, 'Ibrahim Vendor', 'vendor', 'vendor@gmail.com', NULL, '$2y$10$e4iZjqLrNmL0eySezNHyM.tKMhHIc3xd9MzqE.NYd5f3x6w.19EYS', '2023041545png', '01770202036', 'Mirpur,Dhaka,Bangladesh', '2023', 'dustry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic t', 'vendor', 'active', '2023-07-20 17:48:58', 'BmeZjldJkB6lsJRWkJGDZhmoSafiPNk5AYGKSW7H168n6mwjiv8zlbRsT21X', NULL, '2023-07-20 11:48:58'),
(3, NULL, 'User', 'Masud', 'user@gmail.com', NULL, '$2y$10$khLJqo3TBx2R9sZWuvl7pOv7lu/H9e8XyfVIVMBdcJd./MwxqMKJO', '2023041545png', '01770202036', 'Mirpur 10, Block - D, Road -33, House - 19, Dhaka, Bangladesh', '2022', NULL, 'user', 'active', '2023-07-20 17:16:42', NULL, NULL, '2023-07-20 11:16:42'),
(14, NULL, 'AliBaba', 'Robin', 'alibaba@gmail.com', NULL, '$2y$10$0XE2Q7739ADGhN2ES8uJ8exSCTExUWHlb1rAvSVXQ25.zJsiLsxK.', '2023052108jpg', '123456789', 'Kaliakoir,Akrain-birulia road,Savar Dhaka.', '20230429', NULL, 'vendor', 'active', '2023-07-11 23:16:41', '6ntkeleHqHoHqJtOFEvPn6I0KUFfL8tNihxJpetyslQS7cBEZfJbqV3Gn2cI', NULL, '2023-07-11 17:16:41'),
(15, NULL, 'AliBaba', 'Robin', 'alihaha@gmail.com', NULL, '$2y$10$k3vaG78CWHWG9kAvocTS8ujuXAN9vtAuUpzkLqX598EDedr5uxvna', '2023052108jpg', '123456789', 'Kaliakoir,Akrain-birulia road,Savar Dhaka.', '20230429', NULL, 'vendor', 'active', '2023-07-11 23:18:20', 'bttZzh23biSMjxSmbTOXTKCUk2qNjjO99JOj0sGJlrrupJkc2mJkOn9ZcerA', NULL, '2023-07-11 17:18:20'),
(16, NULL, 'Amazon', 'amazon', 'amazon@gmail.com', NULL, '$2y$10$CIeecsWcHXw7ZAMlWImekOiqXXaxMCjWPM4HKyIusfEALO.n.l03O', '2023041659png', '0978688213', 'Bayreuther Strasse 36', '20230429', NULL, 'vendor', 'active', NULL, NULL, NULL, '2023-07-14 15:25:30'),
(17, NULL, 'Ebay', 'ebay', 'ebay@gmail.com', NULL, '$2y$10$IgQ.XXykOPcJFG7.mbZoC.nEw0AWKNZObmpBNrX2a1M5hIgnpVu/O', '2023041703png', '0978688213', 'Bayreuther Strasse 36', '20230429', NULL, 'vendor', 'active', '2023-07-11 23:22:50', 'Xw5J5wmxNBlpsTgWPHLjUfKK2rTHSxNGFW7gJKEl5eyAkNdbH5Sa2jAkMW29', NULL, '2023-07-11 17:22:50'),
(18, NULL, 'Aliexpress', 'Aliexpress', 'Aliexpress@gmail.com', NULL, '$2y$10$ghzmd/ijDGJKJJifPzKbGeHijCkCPJkvTm.Zgdh.FLTOEKpZks.NK', '2023041812jpg', '0978688213', 'Bayreuther Strasse 36', '20230429', NULL, 'vendor', 'active', NULL, 'BLcqI7LLNDiSJH2xbNMN4UzIkY9PJs0HESUXaA5QiSelGdwqoVd5gwxSCvxo', NULL, '2023-07-14 15:25:36'),
(19, NULL, 'ali2Bd', 'man', 'ali2Bd@gmail.com', NULL, '$2y$10$Ns4bTb/fAQcCPjDqShP83eCq9iXNQV/au75ijjuxpCVdNqTdHwwru', '2023052108jpg', '0978688213', 'Bayreuther Strasse 36', '20230505', NULL, 'vendor', 'active', '2023-07-11 23:25:22', 'xNCkIKvR9idc55UxSP3MPpPPahiXEnvQU5LGBdSsm5M9KPfNLmyMnmZkTGiI', NULL, '2023-07-11 17:25:22'),
(20, NULL, 'Baba', 'yaga', 'baba@yaga.com', NULL, '$2y$10$hReTvexhVeNXAL..8wvfIe.2kzYQK6cFdibUjuS3Vkt1kBsgk2aC2', '', '+88451554554', 'mirpur 10', '2022', NULL, 'user', 'active', NULL, NULL, '2023-06-01 17:12:29', NULL),
(22, NULL, 'vas', 'sss', 'davidb2036@gmail.com', NULL, '$2y$10$pRYjYV90DH3RpTOWJ83uwunPbsh5STy54UtHL1MwF5msn3aYimHbS', NULL, NULL, NULL, '2022', NULL, 'user', 'active', NULL, NULL, '2023-06-01 11:16:10', '2023-06-01 11:16:10'),
(65, '3519515704972417', 'Ibrahim', 'Md Ibrahim Khalil', 'mibrahim01723761111@gmail.com', NULL, '$2y$10$uc7ly2J3bwjt.wsSap4MY.6cYDBVHjWLtzUsabCuDDpbIQqyv0lsi', 'https://graph.facebook.com/v3.3/3519515704972417/picture?type=normal', NULL, NULL, '2022', NULL, 'user', 'active', NULL, NULL, '2023-07-08 20:47:06', '2023-07-08 20:47:23'),
(66, '39298707', 'Md Ibrahim Khalil', 'Iam876', 'imuhammad784@gmail.com', NULL, '$2y$10$.2Zo14rvBoc8OzYDdCdfvObUKy.z9FQNrs.CIolJPQvoDzIW6f2eO', 'https://avatars.githubusercontent.com/u/39298707?v=4', NULL, NULL, '2022', NULL, 'vendor', 'active', '2023-07-11 23:16:41', NULL, '2023-07-08 21:25:06', '2023-07-08 21:25:21'),
(67, NULL, 'Ibrahim Khalil', 'admin', 'admin@gmail.com', NULL, '$2y$10$WjNQtDQ3r3tg8cQh2.F4zuVYoJpQSnKzmfiWCU0l1AkFjGQ2a4.Vy', NULL, '01770202036', 'Mirpur 10 Dhaka 1216 Bangladesh', '2022', NULL, 'admin', 'active', '2023-07-20 21:15:10', 'jel0UbIsFXRS3VYwozLvzv87vzDYZXECM5KZvFusMjXS0hCT1Y9ltgpzXKep', '2023-07-19 18:13:15', '2023-07-20 15:15:10'),
(68, NULL, 'Abdullah Al Masud', 'Abdullah', 'masud@gmail.com', NULL, '$2y$10$l9aICOl5ayWKjBlg2Om2DuvILBu/Cmrq3Gxgbtxs/Mwyd84OTQUmS', NULL, '01234567890', 'Mirpur 10 Dhaka 1216 Bangladesh', '2022', NULL, 'admin', 'active', NULL, NULL, '2023-07-19 18:14:25', '2023-07-19 18:14:25'),
(69, NULL, 'Hasibul hasan shanto', 'shanto', 'santo@gmail.com', NULL, '$2y$10$.vi/vSlpI1.o3sSc/Xx1MOTsyV2fWSQ8uCZZRsYxI9BUcwarVCw5i', NULL, '98765432109', '1213 walnut street', '2022', NULL, 'admin', 'active', '2023-07-20 01:26:52', 'Pj8mHD53nG5VGzZ5D99hFe7FW8V8rSUcARZNlj2NxobpOlsGkfJxWMZqEExd', '2023-07-19 18:15:13', '2023-07-19 19:26:52'),
(70, NULL, 'dihan ahmed', 'dihan', 'dihan@gmail.com', NULL, '$2y$10$qawLvB0mgSL4IXCzg4Cl8..GC7y.AsDtM4CIe/FFz0SzNgATTZz5O', NULL, '01234567890', 'Mirpur 10 Dhaka 1216 Bangladesh', '2022', NULL, 'admin', 'active', '2023-07-20 00:16:38', '8gip5EwzvsYkngGS6hiAPHRB24BnPakwQQkIfJOemWSfzu0tmUcnpf9E1aoz', '2023-07-19 18:16:04', '2023-07-19 18:16:38'),
(71, NULL, 'Halum', 'halum2023', 'halum@halum.com', NULL, '$2y$10$u.75KdvMSaIU6FW.ugMx7eE8DKu7x5gFacKyD/lHQRNkQBZKwpmHC', '2023071601png', '12345678900', 'Halum,Halum,HalumHalumHalumHalum', '20230720', NULL, 'vendor', 'active', NULL, NULL, NULL, '2023-07-20 11:41:02'),
(72, NULL, 'halum', 'halum2023', 'halum@gmail.com', NULL, '$2y$10$.1qblDqWe8EMph/MEqL9VOpM5ejaTIN6CO4oxbMMgLkeNw/3TVlae', '2023071608png', '01234567890', 'Bayreuther Strasse 36', '20230720', NULL, 'vendor', 'active', '2023-07-20 17:58:51', 'CLhuI8JX0JhQE0cSHpjYdM4ZWVWtVm9YxA7ziuDXreEnIRzhgL3hmdDEtu0M', NULL, '2023-07-20 11:58:51'),
(73, NULL, 'robin', 'robin2023', 'robin@gmail.com', NULL, '$2y$10$LmXf7WMLKCdgj0Nv8bJEkujVnyQ9uK.DSs6c2WHFfvjgQGvzeyM6S', '2023071616png', '1234567889', 'MIrpur', '20230720', NULL, 'vendor', 'active', NULL, NULL, NULL, '2023-07-20 11:54:35');

-- --------------------------------------------------------

--
-- Table structure for table `wishlists`
--

CREATE TABLE `wishlists` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wishlists`
--

INSERT INTO `wishlists` (`id`, `user_id`, `product_id`, `created_at`, `updated_at`) VALUES
(48, 3, 40, '2023-07-07 16:37:20', NULL),
(49, 3, 42, '2023-07-07 16:39:56', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_categories`
--
ALTER TABLE `blog_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_posts`
--
ALTER TABLE `blog_posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `blog_posts_blog_category_id_foreign` (`blog_category_id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `compare_products`
--
ALTER TABLE `compare_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `multi_images`
--
ALTER TABLE `multi_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_items_order_id_foreign` (`order_id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `review_products`
--
ALTER TABLE `review_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `review_products_product_id_foreign` (`product_id`),
  ADD KEY `review_products_user_id_foreign` (`user_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `seo_settings`
--
ALTER TABLE `seo_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shipping_districts`
--
ALTER TABLE `shipping_districts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shipping_divisions`
--
ALTER TABLE `shipping_divisions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shipping_states`
--
ALTER TABLE `shipping_states`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `site_settings`
--
ALTER TABLE `site_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subcategories_category_id_foreign` (`category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `wishlists`
--
ALTER TABLE `wishlists`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banners`
--
ALTER TABLE `banners`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `blog_categories`
--
ALTER TABLE `blog_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `blog_posts`
--
ALTER TABLE `blog_posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `compare_products`
--
ALTER TABLE `compare_products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `multi_images`
--
ALTER TABLE `multi_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=213;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `review_products`
--
ALTER TABLE `review_products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `seo_settings`
--
ALTER TABLE `seo_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `shipping_districts`
--
ALTER TABLE `shipping_districts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `shipping_divisions`
--
ALTER TABLE `shipping_divisions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `shipping_states`
--
ALTER TABLE `shipping_states`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `site_settings`
--
ALTER TABLE `site_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `subcategories`
--
ALTER TABLE `subcategories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `wishlists`
--
ALTER TABLE `wishlists`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `blog_posts`
--
ALTER TABLE `blog_posts`
  ADD CONSTRAINT `blog_posts_blog_category_id_foreign` FOREIGN KEY (`blog_category_id`) REFERENCES `blog_categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `review_products`
--
ALTER TABLE `review_products`
  ADD CONSTRAINT `review_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `review_products_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD CONSTRAINT `subcategories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
